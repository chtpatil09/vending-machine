# Vending Machine

A simple Python vending machine for still and fizzy water.