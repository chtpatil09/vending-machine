
STILL = 'still'
FIZZY = 'fizzy'

PRICES = {
    STILL: 30,
    FIZZY: 35
}

VALID_COINS = [1, 2, 5, 10]
